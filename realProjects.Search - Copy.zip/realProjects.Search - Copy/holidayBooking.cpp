/***********************************************************************
*1- holidayBooking.cpp
*2- program to implement of data and make booking
*3- Rafik deboub
***********************************************************************/




#include "holidayOffer.h"
#include "holidayBooking.h"


#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include <sstream>
#include <cstdio>
#include <conio.h>
#include <stdlib.h>
#include <vector>


using std::cout;
using std::cin;
using std::vector;
using std::string;
using std::endl;
using std::fstream;







//************ Methodes for customer Booking class


CustomerBooking::CustomerBooking() {
	
	std::ifstream fin("HolidayOffers.txt");
	
				  if(fin) {
				  	while(!fin.eof()){
				  		string holidayId;
				  		getline(fin, holidayId, ':');
				  		
				  		string countryChoice;
				  		getline(fin, countryChoice, ':');
				  		
				  		string category;
				  		getline(fin, category, ':');
				  		
				  		string description;
				  		getline(fin, description, ':');
				  		
				  		string startDate;
				  		getline(fin, startDate, ':');
				  		
				  		string duration;
				  		getline(fin, duration, ':');
				  		
				  		string price;
				  		getline(fin, price);
				  		
				  		
				  		if(!fin.eof()) {
				  			_customerBookings.push_back(HolidayOffer(holidayId, 
							  countryChoice, category, description, startDate, duration, 
							  price));
						  }
				  		
					  }
					  fin.close();
					  cout <<endl;
					  
		  }
}


//***** get attribute from class customer booking



CustomerBooking::CustomerBooking(string customerName, string customerEmail, 

                string holidayId) :_customerName(customerName), 
				_customerEmail(customerEmail), _holidayId(holidayId){    }	
			
			
			
			


			
/*			
			
bool HolidayBooking::isDuplicate(string holidayId) {
	for(HolidayOffer holidayOffer : _holidayOffers) {
		if(holidayId == holidayOffer.getHolidayID()) {
			cout << "ERROR - " << holidayId
				 << " Record already exists.\n";
				 return true;
		}   // end if statement
	} // end for loop
	return false;
}
*/

			
			
			
			
						

void CustomerBooking::choicesOfBooking(){
	
	int _menuChoice;
	
		cout <<"\n\n1. Book Holiday\n";
		cout <<"2. Exit Booking";
		cout <<"\nChoose an option (between 1 & 2): ";
		cin >> _menuChoice;
		cin.ignore();
		cout <<endl;
		if ( _menuChoice == 1 ){
		
		do {
			cout <<endl;
			cout << "============================\n";
			cout << "Customer booking details\n";
			cout << "============================\n";
			cout <<endl;
			cout << "================================================\n";
		cout << "A- Holiday id (Must have eight character): ";
		std::getline(cin, _holidayId, '\n');
		
		} while(_holidayId.length() != 8 );{
			cout << "<<WELL DONE !. valid data>>"<<endl;}
		
		
		 	
			cout << "================================================\n";
			cout <<endl;
			cout << "================================================\n";
			cout << "B- Please Enter customer name: ";
			getline(cin, _customerName);
			cout << "================================================\n";
			
			cout<<endl;
			cout << "================================================\n";
			cout << "C- Please Enter customer Email: ";
			getline(cin, _customerEmail);
			cout << "================================================\n";
		    cout <<endl;
			//cin.ignore();				
			string customerBook = '<'+_customerName  + '>' + '<' + _customerEmail  + '>' + '<' + _holidayId + '>';
			
				
				for(HolidayOffer _hO : _customerBookings){
					

					  if (_holidayId == _hO.getHolidayID()){
					  	
					  	//_hO.displayHolidayOffer();
					  	cout <<endl;
						cout <<  "================================\n";
						cout << "  Holiday offer Booking record\n";
						cout <<  "=================================\n";
						cout <<endl;
					     _hO.displayHolidayOffer();
					     std::ofstream file;
					     std::ifstream myFile;
					     myFile.open("Holiday Booking.txt");
					     file.open("Holiday Booking.txt",std::ios::app);
					     if(myFile.is_open()){
					     	
					     	file<< customerBook<<endl;
					     	file.close();
					     	myFile.close();
					     	cout<<endl;
						 }
					     
					     
		     cout << "booking saved"<<endl;
					     
					     
					     
					     
					     
					     
					     
					     
						
			/*
						fstream myFile;
				
					    myFile.open("Holiday Booking.txt", ios::out); //write
									
						if(myFile.is_open()){
							myFile << customerBook;
							myFile << "\n";
							cout << "\n\n<<Holiday Booking is Saved Successfully!>>\n";
					        myFile.close();
		                }
		                	//fstream myFile;
		                
			   
				   }
				   fstream myFile;
				   	myFile.open("Holiday Booking.txt", ios::app); //Append
					
					        if(myFile.is_open()){
					        	
					       	myFile << customerBook;
							myFile << "\n";
					        myFile.close();}
				   
				   
				   else if (_holidayId != _hO.getHolidayID()){
				   	
				 //  	cout << "No ID found\n";
				   	cout<<endl;
				   	break;
				   	
				   }
			*/	   
			   }
			   
		}
			   
               
        }else if(_menuChoice == 2){
			
			exit(1);
			
		}else {
			cout << "\n<<ERROR - PLEASE TRY AGAIN. USE VALID OPTION (1 OR 2)>>";
			choicesOfBooking();
		}	
}







//****************** CustomerBookingMenu class


CustomerBookingMenu::CustomerBookingMenu(){   }


bool CustomerBookingMenu::selectOpt() {
	
	system ("CLS");
	cout<<endl;
	char optChoice;
	do {
	
	cout << endl;
	cout <<"\n======================\n";
	cout << "Customer booking menu\n===================\n\n"
		 << "(a) Display all holiday Offers\n"
		 << "(b) search holiday offer by CATEGORY\n"
		 << "(c) search holiday offer by COUNTRY\n"
		 << "(d) booking holiday\n"
		 << "(e) stop the program.\n\n"
		 
		 << "Select an Option: ";
		 
		 
		 cin >> optChoice;
		 cin.ignore(10000, '\n');
	
	switch(optChoice) {
		
		case 'A':
		case 'a':
  			 	    cout <<"\n=====================\n";
			 	 	cout << "Holiday offer Record\n==================\n\n";
			 	 _hb.displayallRecord();
			 	 cout << "\n\npress any key to Continue...";
				  getch();
				  system("CLS");
				  break;
				  
		case 'B' :
		case 'b' :
			 	_hb.searchBycategory();
		    	cout << "press any key for main menu...";
				 getch();
				 break;
				 
	    case 'C' :
	    case 'c' :
		 	_hb.searchBycountry();
				 cout << "press any key for main menu...";
				 getch();
				 break;	 
			
		case 'D':	 
	    case 'd' :
		 	_cb.choicesOfBooking();
		 	cout <<endl;
			cout << "press any key for main menu...";
				 getch();
				 break;	
				 
	    case 'E':
		case 'e' :
		 	return false;
		 	
		
  			default: 
		 	
		 	cout << "<<ERROR>> Please Enter 'a', 'b', 'c', 'd'or 'e' without the quotes.\n";
		 			cout << "press any key for main menu...";
					 getch();
					 break; 
		
			}
	
	}while (optChoice != 'e');
	   
	   return true;

}


//********** the end 





 


