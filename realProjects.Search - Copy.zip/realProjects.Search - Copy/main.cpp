#include <iostream>
#include <string>
#include <fstream>

#include "holidayOffer.h"





int main (){
	
	
	
	HolidayBookingMenu holidayBookingMenu;
	
	holidayBookingMenu.select();
	
	//while (holidayBookingMenu.select()) {   }
	
	return 0;	
}



