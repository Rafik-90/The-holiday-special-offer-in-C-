/*****************************************************************************
 * holidayOffer.cpp
 * implementation of holiday offers class ID, country destination, 
 * category, description, duration, startDate, price
 * Rafik deboub
 * program design assignment
 * TEACHER RICHARD HANDY
 * ***************************************************************************/




#include "holidayOffer.h"
#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include <sstream>
#include <cstdio>
#include <conio.h>
#include <stdlib.h>
#include <vector>

using std::string;
using std::cout;
using std::endl;
using std::setw;
using std::left;
using std::cin;
using std::ifstream;
using std::ofstream;
using std::getline;



//const int maxSize = 8;
//char stringSize[maxSize];



//*********************************Methods for holiday offer class
// get attributes data from the keyboard

HolidayOffer::HolidayOffer() {
	
	cout << endl;
	cout << "============================================\n";
	cout <<"Please Enter special holiday offer RECORDS: \n";
	cout <<"=============================================\n";
	
	
	cout <<endl;
	
	
	cout <<"=============================================\n";


do {

		cout << "Holiday id (Must have 8 character): ";
		std::getline(cin, _holidayId, '\n');
		
		} while(_holidayId.length() != 8 );{
			
			cout << "<<WELL DONE !. valid data>>"<<endl;
		}
//		stringstream ss(_holidayId);
//		ss >> stringSize;
//	 	   	  			 if (ss >> stringSize) {
//			cout <<"invalid data !\n";
//			break; } 
		
		
//	}  	while (stringSize[maxSize]);
		cout <<"=============================================\n";
		   
	cout <<endl;   
	   
	   
	 cout <<"\n======================\n";  
	cout <<"Country choice: ";
	getline(cin, _countryChoice, '\n');
	cout <<"=======================\n";
	
	cout <<endl;
	//cout <<"=============================================\n";
		
		cout <<endl;
		
	 int option;	
do {

 
	cout <<"=================\n";
    cout << "Categoty list\n===========\n\n";
    cout <<"1. SKIING"<<endl;
    cout <<"2. City break"<<endl;
    cout <<"3. walking"<<endl;
    cout <<endl;
   
 
    cout << "Please enter what category: ";
	cin >> option;   
    
  
	
    
	cin.ignore(10000, '\n');
	   cout <<endl;
	   
	   switch (option)
	   {
	   	case 1:	
	   		 
	   		 cout <<" <<Skiing, GREAT CHOICE !>>"<<endl;
	   		 _category = "Skiing";
	   		 
	   		 break;
        case 2:
	   		 cout <<" <<City break, GREAT CHOICE !>>"<<	endl;
	   		 _category = "City break";
	   		break;
	   		
		case 3:
   		    cout <<" <<Walking, GREAT CHOICE !>>"<<endl;
   		    _category = "Walking";
   		    break;
   		    
        default:
         		  
  				  if (option != 1 && option != 2 && option != 3 ){
         		  	cout <<"<<ERROR ! (select a choice between 1 and 3)\n\n>>";
         		  }
         		break;
	   		
	   }  
	 
} while (option != 1 && option != 2 && option != 3);
	 
	  

    cout<<endl;
	cout <<"=========================================\n";
	
	cout <<"Description : ";
	getline(cin, _description, '\n');
	
	cout <<"=========================================\n";
	
	cout <<endl;
	
	cout <<"========================\n";
	
	cout <<"Start date is: ";
	getline(cin, _startDate, '\n');
	
	cout <<"========================\n";
	
	cout<<endl;
	
	cout <<"=========================\n";
	
	cout <<"Duration of your stay (days): ";
	getline(cin, _duration, '\n');
	
	cout <<"=========================\n";
	
	cout <<endl;
	
	cout <<"=========================\n";

	cout <<"Price (pound sterling) is: ";
	getline(cin, _price, '\n');
	cout <<"=========================\n";	
	
}



//*******************************************************************
//*******************************************************************

// get attributes data from parameters

//constructor needed when creating a single Holiday record
HolidayOffer::HolidayOffer(string holidayId , string countryChoice,
                string category, string description, string startDate, 
                string duration, string price): 
                _holidayId (holidayId), _countryChoice(countryChoice),
                _category(category), _description(description), _startDate(startDate), 
                _duration(duration), _price(price) {   }





//*********************************************************************
//********************************************************************

// display holiday Offer records


void HolidayOffer:: displayHolidayOffer(){
          
		  
		    cout <<endl;
		    
    
		    cout << "==================================================================\n";
	        cout << " Holiday_ID: " << std::setw(8) << std::left << _holidayId << endl;
	        cout << "==================================================================\n";
            cout << " Holiday destination: " << std::setw(10) << std::left << _countryChoice << endl;
            cout << "==================================================================\n";
            cout << " The Category is: " << std::setw(15) << std::left << _category << endl;
            cout << "==================================================================\n";
            cout << " Holiday descripttion: " << std::setw(10) << std::left << _description <<endl;
            cout << "==================================================================\n";
            cout << " Holiday start day is : " << std::setw(10) << std::left << _startDate << endl;
            cout << "==================================================================\n";
            cout << " Holiday duration will be: " << std::setw(10) << std::left << _duration <<endl;
            cout << "==================================================================\n";
            cout << " The travel cost will come to : " << std::setw(10) << std::left<< _price <<endl; 
            cout << "==================================================================\n";
            
            cout <<endl;
            
}



//***************************************************************
//**************************************************************
// convert record to a string suitabale to retrieve from a file

string HolidayOffer::toString () {

	   return string(_holidayId + ':' + _countryChoice + ':' + _category + ':' + _description + ':' + _startDate + ':' + _duration + ':' + _price);

}


//**************************************************************
//*************************************************************


// return the holiday offer record

string HolidayOffer::getHolidayID() {return _holidayId; }
string HolidayOffer::getCountryChoice() { return _countryChoice; }
string HolidayOffer::getCategory() { return _category; }
string HolidayOffer::getDescription() {return _description; }
string HolidayOffer::getStartDate() { return _startDate; }
string HolidayOffer::getDuration() { return _duration; }
string HolidayOffer::getPrice() { return _price; }







//**************************************************
//****************************************************

//******************** Methods for holidayBooking class

// read records from a file and store in a vector



HolidayBooking::HolidayBooking() {
	

	
	
	std::ifstream fin("HolidayOffers.txt");
	if(fin) {
		
		while(!fin.eof()) {
			string holidayId;
			getline(fin, holidayId, ':');
			
			string countryChoice;
			getline(fin, countryChoice, ':');
			
			string category;
			getline(fin, category, ':');
			
			string description;
			getline(fin, description, ':');
			
			string startDate;
			getline(fin, startDate, ':');
			
			string duration;
			getline(fin, duration, ':');
			
			string price;
				getline(fin, price);
			
						 if(!fin.eof() && (!isDuplicate(holidayId))){
						 	_holidayOffers.push_back(HolidayOffer(holidayId, countryChoice, 
							 category, description, startDate, duration, price));
						 }
		}
		fin.close();
		cout <<endl;
	}
}


















//*********************************************************
//**********************************************************
// convert each record in the vector to a string and write a file



/*
HolidayBooking::~HolidayBooking() {
	
	std::ofstream fout("HolidayOffers.txt");
	
	for (HolidayOffer holidayOffer : _holidayOffers) {
					  fout << holidayOffer.toString() <<endl;
	}
	fout.close();
	cout <<endl;
}

*/



HolidayBooking::~HolidayBooking() {
	
	std::ofstream fout("HolidayOffers.txt");
	for (unsigned int i = 0; i < _holidayOffers.size(); i++) {
		fout << _holidayOffers[i].toString() << endl;
		
	}
	fout.close();
	cout <<endl;
	
}


//*********************************************************
//**************************************************

// create record and add to file


void HolidayBooking::addRecord() {
	
//	_holidayOffers.push_back(HolidayOffer());
	HolidayOffer holidayOffer;
	if(!isDuplicate(holidayOffer.getHolidayID())) {
		_holidayOffers.push_back(holidayOffer);

	}    // end if statement
	
}


//*******************************************************

// display each record in a vector

void HolidayBooking::displayallRecord () {
	for(HolidayOffer holidayOffer : _holidayOffers) 
	{
		holidayOffer.displayHolidayOffer(); }
		cout <<endl;
} 



//**************************************************************
//*****************************************************************
// true if record is already in vector


bool HolidayBooking::isDuplicate(string holidayId) {
	for(HolidayOffer holidayOffer : _holidayOffers) {
		if(holidayId == holidayOffer.getHolidayID()) {
			cout << "ERROR - " << holidayId
				 << " Record already exists.\n";
				 return true;
		}   // end if statement
	} // end for loop
	return false;
}







//*************************************************





void HolidayBooking::updateRecord(){
	
	int i, opt;
	
	for(HolidayOffer holidayOffer : _holidayOffers) {
		cout << "\n\n" << i << ".    ";
		holidayOffer.displayHolidayOffer(); i++;
		cout << endl;
		
	}
	 cout << "Please select what record you want to update ( from 1, 2,..to the end ):";
		 cin >> opt;
		 cin.ignore(10000, '\n');
		_holidayOffers[opt-1] = HolidayOffer();
}



//********************************************************
//**************************************************************


void HolidayBooking::deleteRecord() {
		int i, opt;
	
	for(HolidayOffer holidayOffer : _holidayOffers) {
		cout << "\n\n" << i << ".    ";
		holidayOffer.displayHolidayOffer(); i++;
		cout << endl;
		
	}
	 cout << " select what record you want to delete ( from 1, 2,..to the end ):";
		 cin >> opt;
		 _holidayOffers.erase(_holidayOffers.begin()+ opt - 1);
	
}

//****************************************************



void HolidayBooking::searchBycategory() {
	cout<<endl;
	
	cout<<"Please enter what category (Walking, Skiing, City break) by search: ";
	
	string category;
	getline(cin, category);
	
	for (HolidayOffer holidayOffer : _holidayOffers) {
		
		if(category == holidayOffer.getCategory()) {
			
			cout << "\n========================\n";
			cout << "Holiday has been located\n========================\n\n";
			cout << endl;
			holidayOffer.displayHolidayOffer(); 
			
			
				
	}
	cout <<endl;
}
}




void HolidayBooking::searchBycountry() {
	cout<<endl;
	
	cout<<"Please enter what country by search: ";
	
	
	string countryChoice;
	getline(cin, countryChoice);

	for (HolidayOffer holidayOffer : _holidayOffers) {
		
		
		if(countryChoice == holidayOffer.getCountryChoice()) {
            
			cout << "\n========================\n";
			cout << "Holiday has been located\n========================\n\n";
				 
				 	holidayOffer.displayHolidayOffer(); 
			
	}
	cout <<endl;
}



}



void HolidayBookingMenu::checkExistfile(){
    
	
	fstream myFile;
	myFile.open("HolidayOffers.txt", ios::in); //READ
	
	if (myFile.is_open()){
		string _line;
		
		while (getline(myFile, _line)){
			cout <<_line <<endl;
		}
		myFile.close();
	} else {
		cout << "No Record File found";
	}
	
}














//************************************Methods for enu class
// constructor

HolidayBookingMenu::HolidayBookingMenu() {  }

// display menu

bool HolidayBookingMenu::select() {
	
	system ("CLS");
	cout<<endl;
	char choice;
	do {
	
	cout << endl;
	cout <<"\n======================\n";
	cout << "Holiday booking menu\n===================\n\n"
		 << "(a) Check whether Record File exist\n"
		 << "(b) Add a record\n"
		 << "(c) Display all records\n"
		 << "(d) update Particular record\n"
		 << "(e) search by category\n"
		 << "(f) search by country\n"
		 << "(g) delete Particular record\n"
		 << "(h) save and stop the program.\n\n"
 
		 << "Select: ";
		 
		 //char choice;
		 cin >> choice;
		 cin.ignore(10000, '\n');
		 
		 switch (choice) {
		 	
		 	case 'A' :
	 		case 'a' :
	 	 
		    checkExistfile();
		 	cout << "\n\npress any key for main menu...";
		 		getch();
		 		break;
		 	
		 	
		 	
			case 'B' :		 
		 	case 'b' :
		 		_hb.addRecord();
		 	//	system ("CLS");
		 		cout << "\n\npress any key for main menu...";
		 		getch();
		 		break;
		 		
		 	case 'C' :
		    case 'c' :
			 	 _hb.displayallRecord();
			 	 cout << "\n\npress any key for main menu...";
				  getch();
				  break;
			
			case 'D' :
			case 'd' :
				 _hb.updateRecord();
				 cout << "press any key for main menu...";
				 getch();
				 break;
				 
			case 'E' :	 
		    case 'e' :
		    	_hb.searchBycategory();
		    	
		    	cout << "press any key for main menu...";
				 getch();
				 cin.ignore();
				 break;
				 
			case 'F' :
			case 'f' :
			
				 _hb.searchBycountry();
				 cout << "press any key for main menu...";
				 getch();
				 cin.ignore();
				 break;	 
				
			case 'G' :
			case 'g' :
				 _hb.deleteRecord();
				 cout << "press any key for main menu...";
				 getch();
				 break;
				
				 
			case 'H' :	 
			case 'h' :
				 return false;
				 		
 		  default:
		
		cout<< "<<ERROR>> Please Enter eiter in 'a', 'b', 'c', 'd', 'e' , or 'g' or in capital letters without the quotes.\n";
		    cout << "press any key for main menu...";
				 getch();
			
				 break; 
		 }
		 
	}while ( choice != 'h' && choice != 'H');
		 return true;	

}




