/***********************************************************************
 * HolidayOffer.h
 * HolidayOffer class _holidayId , _countryChoice,
  _category, _description, _startDate, 
  _duration, price 
 * RAFIK DEBOUB
 * program design Assigmnent 02
 * version 1
 * Richard Handy 
 * ********************************************************************/

#ifndef HolidayOffer_H
#define HolidayOffer_H

#include <string>
#include <vector>


using std::string;
using std::vector;


class HolidayOffer{
    private:
    	
    	
            string _holidayId;
            string _countryChoice;
            string _category;
            string _description;
            string _startDate;
            string _duration;
            string _price;
			 
    public:
    	
    	     HolidayOffer();
            HolidayOffer(string holidayId , string countryChoice,
              string category, string description, string startDate
			  , string duration, string price );
          
            void displayHolidayOffer();
            
            
            string toString();
            string getHolidayID();
            string getCountryChoice();
            string getCategory();
            string getDescription();
            string getStartDate();
            string getDuration();
            string getPrice();

};  




//************************************ A container class for records


class HolidayBooking {
	
	private : 
			std::vector<HolidayOffer> _holidayOffers;
			bool isDuplicate(string holidayId);

	public :
		   HolidayBooking();
          ~HolidayBooking();
          
          
		   void addRecord();
		   void displayallRecord();
		   void deleteRecord();
		   void updateRecord();
		   void searchBycategory();
		   void searchBycountry();  	
	
	
}; 


//***************** the meneu class for holiday booking 



class HolidayBookingMenu {
	private :
			HolidayBooking _hb;
			
	public :
		   HolidayBookingMenu();
		   bool select();	   
		   void checkExistfile();			
};


#endif  
