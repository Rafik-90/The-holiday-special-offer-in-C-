/**********************************************************************
*1- holidayBooking.h (header file)
*2- proram to store holiday special offer record
*3- Rafik deboub

***********************************************************************/

#include "holidayOffer.h"

#ifndef HOLIDAYBOOKING_H
#define HOLIDAYBOOKING_H

#include <iostream>
#include <vector>

using namespace std;



class CustomerBooking {
	
	private :
	std::vector<HolidayOffer> _customerBookings;
	string _customerName;
	string _customerEmail;
	string _holidayId;
	bool  isDuplicate(string holidayId);
	public :
	
		   CustomerBooking();
		   CustomerBooking(string customerName, string customerEmail, string holidaId);
		   void displayCustomerbooking();
		  // string toString ();
		   string getCustomerName();
		   string getCustomeremail();
		   string getHolidayID();
		   void choicesOfBooking();
		 
		   
		   	   	
};

class CustomerBookingMenu {
	
	private : 
			CustomerBooking _cb;
			HolidayBooking _hb;
	public :
		
		CustomerBookingMenu();
		bool selectOpt();
};


#endif

/*
//************************************ A container class fro records


class HolidayBooking {
	
	private : 
			_hOffers;
			bool isDuplicate(string holidayId);

	public :
		   HolidayBooking();
          ~HolidayBooking();
		   void addRecord();
		   void displayallRecord();
		 
	
	
}; 

*/
