/***********************************************************************
* Main customer booking file
* execute the 2nd program
* Rafik deboub
* verison 1
***********************************************************************/
#include "holidayOffer.h"
#include "holidayBooking.h"
#include <iostream>

/* run this program using the console pauser or add your own getch, 
system("pause") or input loop */


using std::cout;
using std::cin;
using std::endl;
using std::string;







int main() {

	CustomerBookingMenu customerBookingMenu;
	
	customerBookingMenu.selectOpt();


	return 0;
}

